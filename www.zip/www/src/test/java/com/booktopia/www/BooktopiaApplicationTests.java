package com.booktopia.www;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooktopiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
